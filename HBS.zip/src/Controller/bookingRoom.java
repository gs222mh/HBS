package Controller;

import Main.main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.net.URL;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.ResourceBundle;

public class bookingRoom implements Initializable {
    @FXML
    protected Button cancelBtn;
    @FXML
    protected Text roomNumber;
    @FXML
    protected Text pris;
    @FXML
    protected Text roomTyp;

    @FXML
    protected TextField fName;
    @FXML
    protected TextField lName;
    @FXML
    protected DatePicker enDate;
    @FXML
    protected DatePicker exDate;
    private int roomNum;
    private String roomType;
    private String hotelName;
    private File select = null;

    //Close the stage
    public void close() throws IOException {
        Stage stage = (Stage) cancelBtn.getScene().getWindow();
        stage.close();
    }

    //Saving the information of the person into json
    public void save() throws JSONException, IOException {
        boxBorder();
        File f = new File("hotels/" + hotelName + "RoomBooking.json");
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            readWriteFiles rwf = new readWriteFiles();
            JSONArray roomArr = rwf.dbRead(f);
            if (!fName.getText().equals("") && !lName.getText().equals("") && !enDate.getValue().toString().equals("") && !exDate.getValue().toString().equals("")) {
                roomArr.getJSONObject(roomNum - 1).put("Status", "Unavailable");
                roomArr.getJSONObject(roomNum - 1).put("FName", fName.getText());
                roomArr.getJSONObject(roomNum - 1).put("LName", lName.getText());
                roomArr.getJSONObject(roomNum - 1).put("EnterDate", enDate.getValue().toString());
                roomArr.getJSONObject(roomNum - 1).put("EndDate", exDate.getValue().toString());
                rwf.dbWrite(roomArr, f);
                close();
                Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/bookingManage.fxml")));
                Scene scene = new Scene(root);
                MainControll.bookingStage.setScene(scene);
                MainControll.bookingStage.show();
                MainControll.bookingStage.setAlwaysOnTop(true);
                MainControll.bookingStage.setAlwaysOnTop(false);
            }
            if (fName.getText().equals("")) fName.setStyle("-fx-text-box-border: #B22222;");
            if (lName.getText().equals("")) lName.setStyle("-fx-text-box-border: #B22222;");
            if (enDate.getValue().toString().equals("")) enDate.setStyle("-fx-text-box-border: #B22222;");
            if (exDate.getValue().toString().equals("")) exDate.setStyle("-fx-text-box-border: #B22222;");
        }
    }

    //Get the box basic color back
    public void boxBorder() {
        fName.setStyle("-fx-text-box-border: #EBE9ED;");
        lName.setStyle("-fx-text-box-border: #EBE9ED;");
        enDate.setStyle("-fx-text-box-border: #EBE9ED;");
        exDate.setStyle("-fx-text-box-border: #EBE9ED;");
    }

    //Remove the person from the room and set the room Available again
    public void remove() throws JSONException, IOException {
        File f = new File("hotels/" + hotelName + "RoomBooking.json");
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            readWriteFiles rwf = new readWriteFiles();
            JSONArray roomArr = rwf.dbRead(f);
            roomArr.getJSONObject(roomNum - 1).put("Status", "Available");
            roomArr.getJSONObject(roomNum - 1).put("FName", "");
            roomArr.getJSONObject(roomNum - 1).put("LName", "");
            roomArr.getJSONObject(roomNum - 1).put("EnterDate", "");
            roomArr.getJSONObject(roomNum - 1).put("EndDate", "");
            rwf.dbWrite(roomArr, f);
            close();
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/bookingManage.fxml")));
            Scene scene = new Scene(root);
            MainControll.bookingStage.setScene(scene);
            MainControll.bookingStage.show();
            MainControll.bookingStage.setAlwaysOnTop(true);
            MainControll.bookingStage.setAlwaysOnTop(false);
        }
    }

    //Calculate how many days will the person stay and multiply it with the pris
    @FXML
    private void calculatePris() throws IOException, ParseException {
        if (!enDate.getValue().toString().equals("") && !exDate.getValue().toString().equals("")) {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy MM dd");
            String start = enDate.getValue().toString().replace("-", " ");
            String end = exDate.getValue().toString().replace("-", " ");
            LocalDateTime date1 = LocalDate.parse(start, dtf).atStartOfDay();
            LocalDateTime date2 = LocalDate.parse(end, dtf).atStartOfDay();
            long daysBetween = Duration.between(date1, date2).toDays();
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(new FileReader("hotels/BasicInfo" + hotelName + ".json"));
            org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject) obj;
            org.json.simple.JSONObject prisInfo = (org.json.simple.JSONObject) jsonObject.get("prisInfo");
            int priss = Integer.parseInt(prisInfo.get(roomType.toLowerCase() + "Pris").toString().replace("$", ""));
            long total = priss * daysBetween;
            pris.setText(total + "$");
        }
    }

    //Reload the data from the json file
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        UserHolder holder = UserHolder.getInstance();
        User u = holder.getUser();
        roomNum = u.getRoomNum();
        roomType = u.getRoomType();
        roomNumber.setText(String.valueOf(roomNum));
        roomTyp.setText(roomType);
        hotelName = u.getName();
        File f = new File("hotels/" + hotelName + "RoomBooking.json");

        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            readWriteFiles rwf = new readWriteFiles();
            JSONArray roomArr = rwf.dbRead(f);
            try {
                if (!roomArr.getJSONObject(roomNum - 1).get("FName").equals("") && !roomArr.getJSONObject(roomNum - 1).get("LName").equals("")) {
                    fName.setText(roomArr.getJSONObject(roomNum - 1).get("FName").toString());
                    lName.setText(roomArr.getJSONObject(roomNum - 1).get("LName").toString());
                    enDate.setValue(LocalDate.parse(roomArr.getJSONObject(roomNum - 1).get("EnterDate").toString()));
                    exDate.setValue(LocalDate.parse(roomArr.getJSONObject(roomNum - 1).get("EndDate").toString()));
                }
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        setDate();
    }

    //Cannot select date before today
    public void setDate() {
        enDate.setDayCellFactory(picker -> new DateCell() {
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                LocalDate today = LocalDate.now();
                setDisable(empty || date.compareTo(today) < 0);
            }
        });
        exDate.setDayCellFactory(picker -> new DateCell() {
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                LocalDate today = LocalDate.now();
                setDisable(empty || date.compareTo(today) < 1);
            }
        });
    }
}
