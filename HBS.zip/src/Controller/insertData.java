package Controller;

import javafx.scene.control.Button;

public class insertData {
    private String roomType;
    private int roomNo;
    private String status;
    private String info;
    private Button btn;


    public insertData(String roomType, int roomNo, String status, String info, Button button) {
        this.roomType = roomType;
        this.roomNo = roomNo;
        this.status = status;
        this.info = info;
        this.btn = button;
    }

    public insertData() {

    }
    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public void setRoomNo(int roomNo) {
        this.roomNo = roomNo;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getRoomType() {
        return roomType;
    }

    public int getRoomNo() {
        return roomNo;
    }

    public String getStatus() {
        return status;
    }

    public String getInfo() {
        return info;
    }

    public void setBtn(Button btn) {
        this.btn = btn;
    }

    public Button getBtn() {
        return btn;
    }
}
