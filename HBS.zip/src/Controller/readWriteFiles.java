package Controller;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class readWriteFiles {
    private JSONArray loadFile = new JSONArray();
    private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd/HH:mm:ss");
    private LocalDateTime now = LocalDateTime.now();

    //Copy the file to process the data
    public void copy(String path, String hotelsName) {
        File original = new File(path);
        File copied = new File("hotels/processingData-BasicInfo" + hotelsName);
        try (
                InputStream in = new BufferedInputStream(
                        new FileInputStream(original));
                OutputStream out = new BufferedOutputStream(
                        new FileOutputStream(copied))) {

            byte[] buffer = new byte[1024];
            int lengthRead;
            while ((lengthRead = in.read(buffer)) > 0) {
                out.write(buffer, 0, lengthRead);
                out.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Create login file and save the id of the room
    public void loginFile(String event, String hotelName) {
        try {
            Writer output;
            output = new BufferedWriter(new FileWriter("hotels/loginFIle" + hotelName + ".txt", true));
            output.append("Date/Time: " + dtf.format(now) + " Event: " + event + "\n");
            output.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Read the file and return it as JsonArray
    public JSONArray dbRead(File file) {
        try (Scanner sT = new Scanner(file)) {
            String text = "";
            JSONObject obj;
            while (sT.hasNext()) {
                text = sT.nextLine();
                obj = new JSONObject(text);
                loadFile.put(obj);
            }
        } catch (IOException | JSONException e) {
            e.getMessage();
        }
        return loadFile;
    }

    //Get JsonArray and which file you want to put the information in
    public void dbWrite(JSONArray list, File file) {
        try (PrintWriter writer = new PrintWriter(file)) {
            //Remove all thing from file
            writer.print("");
            if (!file.createNewFile()) {
                try (FileWriter input = new FileWriter(file, true)) {
                    for (int i = 0; i < list.length(); i++)
                        input.write(list.getJSONObject(i) + "\n");
                }
            } else {
                try (FileWriter fr = new FileWriter(file, true)) {
                    for (int i = 0; i < list.length(); i++)
                        fr.write(list.getJSONObject(i) + "\n");
                }
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
    }
}
