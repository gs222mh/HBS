package Controller;

import Main.main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.ResourceBundle;

public class create implements Initializable {
    @FXML
    protected Button cancelBtn;
    @FXML
    protected Button nextBtn;
    @FXML
    protected Button addImage;
    @FXML
    protected TextField hotelName;
    @FXML
    protected TextField country;
    @FXML
    protected TextField city;
    @FXML
    protected TextField tel;
    @FXML
    protected TextField email;
    @FXML
    protected TextField username;
    @FXML
    protected PasswordField pass;
    @FXML
    protected ChoiceBox<Integer> single;
    @FXML
    protected ChoiceBox<Integer> triple;
    @FXML
    protected ChoiceBox<Integer> double1;
    @FXML
    protected ChoiceBox<Integer> twin;
    @FXML
    protected ChoiceBox<Integer> king;
    @FXML
    protected ChoiceBox<Integer> quad;
    @FXML
    protected ChoiceBox<Integer> queen;
    @FXML
    protected ChoiceBox<Integer> studio;
    @FXML
    protected ChoiceBox<String> sip;
    @FXML
    protected ChoiceBox<String> dp;
    @FXML
    protected ChoiceBox<String> trp;
    @FXML
    protected ChoiceBox<String> kp;
    @FXML
    protected ChoiceBox<String> qp;
    @FXML
    protected ChoiceBox<String> quep;
    @FXML
    protected ChoiceBox<String> sp;
    @FXML
    protected ChoiceBox<String> tp;
    @FXML
    protected ImageView hotelImage;
    private File select = null;

    private final ObservableList<Integer> numOfRoom = FXCollections.observableArrayList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
    private final ObservableList<String> prisNum = FXCollections.observableArrayList("5$", "10$", "15$", "20$", "25$", "30$", "35$", "40$", "45$", "50$", "55$", "60$", "65$", "70$", "75$", "80$", "85$", "90$", "95$", "100$");

    //close the new window
    public void close() {
        Stage stage = (Stage) cancelBtn.getScene().getWindow();
        stage.close();
    }

    //Go to the next step if all basic information are good
    public void next() throws IOException, JSONException, NoSuchAlgorithmException, NullPointerException {
        boxBorder();
        if (!hotelName.getText().equals("") && !country.getText().equals("") && !city.getText().equals("") && !tel.getText().equals("") && !email.getText().equals("") && !select.getAbsolutePath().equals("") && !username.getText().equals("") && !pass.getText().equals("")) {
            if (createFile()) {
                close();
                savingInfo("hotels/BasicInfo" + hotelName.getText() + ".json");
            } else {
                hotelName.setStyle("-fx-text-box-border: #B22222;");
            }
        }
        if (hotelName.getText().equals("")) hotelName.setStyle("-fx-text-box-border: #B22222;");
        if (country.getText().equals("")) country.setStyle("-fx-text-box-border: #B22222;");
        if (city.getText().equals("")) city.setStyle("-fx-text-box-border: #B22222;");
        if (tel.getText().equals("")) tel.setStyle("-fx-text-box-border: #B22222;");
        if (email.getText().equals("")) email.setStyle("-fx-text-box-border: #B22222;");
        if (select == null) addImage.setStyle("-fx-border-color: #B22222;");
        if (username.getText().equals("")) username.setStyle("-fx-border-color: #B22222;");
        if (pass.getText().equals("")) pass.setStyle("-fx-border-color: #B22222;");
    }

    //Get back to the default box-border
    public void boxBorder() {
        hotelName.setStyle("-fx-text-box-border: #EBE9ED;");
        country.setStyle("-fx-text-box-border: #EBE9ED;");
        city.setStyle("-fx-text-box-border: #EBE9ED;");
        tel.setStyle("-fx-text-box-border: #EBE9ED;");
        email.setStyle("-fx-text-box-border: #EBE9ED;");
        addImage.setStyle("-fx-text-box-border: #EBE9ED;");
        username.setStyle("-fx-text-box-border: #EBE9ED;");
        pass.setStyle("-fx-text-box-border: #EBE9ED;");
    }

    //Create a json file to save all data
    public boolean createFile() {
        boolean fileExist = true;
        File theDir = new File("hotels");
        if (!theDir.exists()) {
            theDir.mkdirs();
        }
        try {
            File myObj = new File("hotels/BasicInfo" + hotelName.getText() + ".json");
            if (!myObj.createNewFile()) {
                fileExist = false;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileExist;
    }

    //Saving all data on the json file
    public void savingInfo(String filename) throws JSONException, IOException, NoSuchAlgorithmException {
        JSONObject hotelInfo = new JSONObject();
        hotelInfo.put("hotelName", hotelName.getText());
        hotelInfo.put("country", country.getText());
        hotelInfo.put("city", city.getText());
        hotelInfo.put("tel", tel.getText());
        hotelInfo.put("email", email.getText());
        hotelInfo.put("imageURL", select.getAbsolutePath());
        hotelInfo.put("single", single.getValue());
        hotelInfo.put("double", double1.getValue());
        hotelInfo.put("triple", triple.getValue());
        hotelInfo.put("king", king.getValue());
        hotelInfo.put("queen", queen.getValue());
        hotelInfo.put("quad", quad.getValue());
        hotelInfo.put("twin", twin.getValue());
        hotelInfo.put("studio", studio.getValue());
        JSONObject adminInfo = new JSONObject();
        hashing hashing = new hashing();
        adminInfo.put("adminUsername", username.getText());
        adminInfo.put("adminPassword", hashing.hasing(pass.getText()));
        JSONObject prisInfo = new JSONObject();
        prisInfo.put("singlePris", sip.getValue());
        prisInfo.put("doublePris", dp.getValue());
        prisInfo.put("triplePris", trp.getValue());
        prisInfo.put("kingPris", kp.getValue());
        prisInfo.put("queenPris", quep.getValue());
        prisInfo.put("quadPris", qp.getValue());
        prisInfo.put("twinPris", tp.getValue());
        prisInfo.put("studioPris", sp.getValue());
        JSONObject mainObj = new JSONObject();
        mainObj.put("admin", adminInfo);
        mainObj.put("hotelInfo", hotelInfo);
        mainObj.put("prisInfo", prisInfo);
        Files.write(Paths.get(filename), Collections.singleton(mainObj.toString()));
        createRoomFile(hotelName.getText());
    }

    //Create the room file and calculate how many rooms are there
    private void createRoomFile(String hotelName) {
        File f = new File("hotels/" + hotelName + "RoomBooking.json");
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        readWriteFiles rwf = new readWriteFiles();
        JSONArray roomArr = new JSONArray();
        org.json.simple.JSONObject roomInfo = new org.json.simple.JSONObject();
        org.json.simple.JSONObject mainObj = new org.json.simple.JSONObject();
        if (single.getValue() != 0)
            for (int i = 1; i <= single.getValue(); i++) {
                roomInfo.put("RoomType", "Single");
                roomInfo.put("RoomNO", i);
                roomInfo.put("Status", "Available");
                roomInfo.put("EnterDate", "");
                roomInfo.put("EndDate", "");
                roomInfo.put("FName", "");
                roomInfo.put("LName", "");
                roomInfo.put("Image", "");
                roomArr.put(roomInfo);
            }
        if (double1.getValue() != 0)
            for (int i = 1; i <= double1.getValue(); i++) {
                roomInfo.put("RoomType", "Double");
                roomInfo.put("RoomNO", single.getValue() + i);
                roomInfo.put("Status", "Available");
                roomInfo.put("EnterDate", "");
                roomInfo.put("EndDate", "");
                roomInfo.put("FName", "");
                roomInfo.put("LName", "");
                roomInfo.put("Image", "");
                roomArr.put(roomInfo);
            }
        if (triple.getValue() != 0)
            for (int i = 1; i <= triple.getValue(); i++) {
                roomInfo.put("RoomType", "Triple");
                roomInfo.put("RoomNO", single.getValue() + double1.getValue() + i);
                roomInfo.put("Status", "Available");
                roomInfo.put("EnterDate", "");
                roomInfo.put("EndDate", "");
                roomInfo.put("FName", "");
                roomInfo.put("LName", "");
                roomInfo.put("Image", "");
                roomArr.put(roomInfo);
            }
        if (king.getValue() != 0)
            for (int i = 1; i <= king.getValue(); i++) {
                roomInfo.put("RoomType", "King");
                roomInfo.put("RoomNO", single.getValue() + double1.getValue() + triple.getValue() + i);
                roomInfo.put("Status", "Available");
                roomInfo.put("EnterDate", "");
                roomInfo.put("EndDate", "");
                roomInfo.put("FName", "");
                roomInfo.put("LName", "");
                roomInfo.put("Image", "");
                roomArr.put(roomInfo);
            }
        if (queen.getValue() != 0)
            for (int i = 1; i <= queen.getValue(); i++) {
                roomInfo.put("RoomType", "Queen");
                roomInfo.put("RoomNO", single.getValue() + double1.getValue() + triple.getValue() + king.getValue() + i);
                roomInfo.put("Status", "Available");
                roomInfo.put("EnterDate", "");
                roomInfo.put("EndDate", "");
                roomInfo.put("FName", "");
                roomInfo.put("LName", "");
                roomInfo.put("Image", "");
                roomArr.put(roomInfo);
            }
        if (quad.getValue() != 0)
            for (int i = 1; i <= quad.getValue(); i++) {
                roomInfo.put("RoomType", "Quad");
                roomInfo.put("RoomNO", single.getValue() + double1.getValue() + triple.getValue() + king.getValue() + queen.getValue() + i);
                roomInfo.put("Status", "Available");
                roomInfo.put("EnterDate", "");
                roomInfo.put("EndDate", "");
                roomInfo.put("FName", "");
                roomInfo.put("LName", "");
                roomInfo.put("Image", "");
                roomArr.put(roomInfo);
            }
        if (twin.getValue() != 0)
            for (int i = 1; i <= twin.getValue(); i++) {
                roomInfo.put("RoomType", "Twin");
                roomInfo.put("RoomNO", single.getValue() + double1.getValue() + triple.getValue() + king.getValue() + queen.getValue() + quad.getValue() + i);
                roomInfo.put("Status", "Available");
                roomInfo.put("EnterDate", "");
                roomInfo.put("EndDate", "");
                roomInfo.put("FName", "");
                roomInfo.put("LName", "");
                roomInfo.put("Image", "");
                roomArr.put(roomInfo);
            }
        if (studio.getValue() != 0)
            for (int i = 1; i <= studio.getValue(); i++) {
                roomInfo.put("RoomType", "Studio");
                roomInfo.put("RoomNO", single.getValue() + double1.getValue() + triple.getValue() + king.getValue() + queen.getValue() + quad.getValue() + twin.getValue() + i);
                roomInfo.put("Status", "Available");
                roomInfo.put("EnterDate", "");
                roomInfo.put("EndDate", "");
                roomInfo.put("FName", "");
                roomInfo.put("LName", "");
                roomInfo.put("Image", "");
                roomArr.put(roomInfo);
            }
        mainObj.put("Rooms", roomArr);
        rwf.dbWrite(roomArr, f);
    }

    //Select the image and get the URL
    @FXML
    private void selectImage() throws FileNotFoundException {
        FileChooser file = new FileChooser();
        file.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Images", "*.*"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("JPGE", "*.jpge"),
                new FileChooser.ExtensionFilter("PNG", "*.png"));
        select = file.showOpenDialog(main.primaryStage);
        InputStream stream = new FileInputStream(select.getAbsolutePath());
        Image image = new Image(stream);
        hotelImage.setImage(image);
    }

    //In the beginning set the number of rooms to 0 and all pris to 0$
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        single.setValue(0);
        double1.setValue(0);
        triple.setValue(0);
        quad.setValue(0);
        queen.setValue(0);
        king.setValue(0);
        studio.setValue(0);
        twin.setValue(0);

        single.setItems(numOfRoom);
        double1.setItems(numOfRoom);
        triple.setItems(numOfRoom);
        quad.setItems(numOfRoom);
        queen.setItems(numOfRoom);
        king.setItems(numOfRoom);
        studio.setItems(numOfRoom);
        twin.setItems(numOfRoom);

        sip.setValue("0$");
        dp.setValue("0$");
        trp.setValue("0$");
        qp.setValue("0$");
        quep.setValue("0$");
        kp.setValue("0$");
        sp.setValue("0$");
        tp.setValue("0$");

        sip.setItems(prisNum);
        dp.setItems(prisNum);
        trp.setItems(prisNum);
        qp.setItems(prisNum);
        quep.setItems(prisNum);
        kp.setItems(prisNum);
        sp.setItems(prisNum);
        tp.setItems(prisNum);
    }
}
