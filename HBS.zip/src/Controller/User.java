package Controller;

public class User {
    private String hotelName;
    private int roomNum;
    private String roomType;

    public User() {}

    public void setName(String name) {
        this.hotelName = name;
    }

    public String getName() {
        return hotelName;
    }

    public void setRoomNum(int roomNum) {
        this.roomNum = roomNum;
    }

    public int getRoomNum() {
        return roomNum;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public String getRoomType() {
        return roomType;
    }
}
