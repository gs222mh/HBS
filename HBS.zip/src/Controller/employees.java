package Controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;
import java.util.ResourceBundle;

public class employees implements Initializable {
    @FXML
    protected TextField fullName;
    @FXML
    protected TextField username;
    @FXML
    protected PasswordField password;
    @FXML
    protected Button saveBtn;
    @FXML
    protected Button removeBtn;
    @FXML
    protected ListView<Object> employeesList;
    private String hotelName;

    //Save the Employees info
    public void saveBtn(ActionEvent event) throws JSONException, NoSuchAlgorithmException, IOException {
        boxBorder();
        if (!fullName.getText().equals("") && !username.getText().equals("") && !password.getText().equals("")) {
            boolean check = false;
            File f = new File("hotels/" + hotelName + "Employees.json");
            readWriteFiles rwf = new readWriteFiles();
            JSONArray employeesArr = rwf.dbRead(f);
            JSONObject employeesInfo = new JSONObject();
            for (int i = 0; i < employeesArr.length(); i++) {
                if (employeesArr.getJSONObject(i).get("fullName").equals(fullName.getText().toUpperCase())) {
                    check = true;
                }
            }
            if (check) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Error");
                alert.setHeaderText("This name have already in DB");
                alert.show();
            } else {
                hashing hashing = new hashing();
                employeesInfo.put("fullName", fullName.getText().toUpperCase());
                employeesInfo.put("Username", username.getText());
                employeesInfo.put("Password", hashing.hasing(password.getText()));
                employeesArr.put(employeesInfo);
                JSONObject mainObj = new JSONObject();
                mainObj.put("emplyees", employeesArr);
                rwf.dbWrite(employeesArr, f);
                Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/employees.fxml")));
                Scene scene = new Scene(root);
                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(scene);
                window.show();
            }
        }
        if (username.getText().equals("")) username.setStyle("-fx-text-box-border: #B22222;");
        if (password.getText().equals("")) password.setStyle("-fx-text-box-border: #B22222;");
        if (fullName.getText().equals("")) fullName.setStyle("-fx-text-box-border: #B22222;");
    }

    //Get the basic color of boxBorder
    public void boxBorder() {
        fullName.setStyle("-fx-text-box-border: #EBE9ED;");
        username.setStyle("-fx-text-box-border: #EBE9ED;");
        password.setStyle("-fx-text-box-border: #EBE9ED;");
    }

    //Double click to get the employee information and reset the password
    public void editEmployees(MouseEvent mouseEvent) throws JSONException {
        if (employeesList.getSelectionModel().getSelectedItem() != null) {
            if (mouseEvent.getClickCount() == 2) {
                saveBtn.setDisable(true);
                fullName.setText(String.valueOf(employeesList.getSelectionModel().getSelectedItem()));
                fullName.setDisable(true);
                File f = new File("hotels/" + hotelName + "Employees.json");
                readWriteFiles rwf = new readWriteFiles();
                JSONArray employeesArr = rwf.dbRead(f);
                for (int i = 0; i < employeesArr.length(); i++) {
                    if (employeesArr.getJSONObject(i).get("fullName").toString().equals(employeesList.getSelectionModel().getSelectedItem())) {
                        username.setText(employeesArr.getJSONObject(i).get("Username").toString());
                    }
                }
            }
        }
    }

    //After getting the data you can reset the password here of chane the username
    public void editBtn(ActionEvent event) throws JSONException, NoSuchAlgorithmException, IOException {
        boxBorder();
        if (fullName.isDisable() && !username.getText().equals("") && !password.getText().equals("")) {
            File f = new File("hotels/" + hotelName + "Employees.json");
            readWriteFiles rwf = new readWriteFiles();
            JSONArray employeesArr = rwf.dbRead(f);
            for (int i = 0; i < employeesArr.length(); i++) {
                if (employeesArr.getJSONObject(i).get("fullName").toString().equals(fullName.getText())) {
                    hashing hashing = new hashing();
                    employeesArr.getJSONObject(i).put("Username", username.getText());
                    employeesArr.getJSONObject(i).put("Password", hashing.hasing(password.getText()));
                    rwf.dbWrite(employeesArr, f);
                    Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/employees.fxml")));
                    Scene loginScene = new Scene(root);
                    Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    window.setScene(loginScene);
                    window.show();
                }
            }
        }
        if (username.getText().equals("")) username.setStyle("-fx-text-box-border: #B22222;");
        if (password.getText().equals("")) password.setStyle("-fx-text-box-border: #B22222;");
    }

    //Remove Employees
    public void remove(ActionEvent event) throws JSONException, IOException {
        if (employeesList.getSelectionModel().getSelectedItem() != null) {
            File f = new File("hotels/" + hotelName + "Employees.json");
            readWriteFiles rwf = new readWriteFiles();
            JSONArray employeesArr = rwf.dbRead(f);
            for (int i = 0; i < employeesArr.length(); i++) {
                if (employeesArr.getJSONObject(i).get("fullName").toString().equals(employeesList.getSelectionModel().getSelectedItem())) {
                    employeesArr.remove(i);
                    rwf.dbWrite(employeesArr, f);
                    Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/employees.fxml")));
                    Scene loginScene = new Scene(root);
                    Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    window.setScene(loginScene);
                    window.show();
                }
            }
        }
    }

    //Reload all data and set the Employees in list
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        UserHolder holder = UserHolder.getInstance();
        User u = holder.getUser();
        hotelName = u.getName();
        File f = new File("hotels/" + hotelName + "Employees.json");
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            readWriteFiles rwf = new readWriteFiles();
            JSONArray employeesArr = rwf.dbRead(f);
            for (int i = 0; i < employeesArr.length(); i++) {
                try {
                    employeesList.getItems().add(employeesArr.getJSONObject(i).get("fullName"));
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}