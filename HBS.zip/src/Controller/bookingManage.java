package Controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Callback;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.*;
import java.net.URL;
import java.util.*;


public class bookingManage extends bookingRoom implements Initializable {

    @FXML
    protected TableView<insertData> table;
    @FXML
    protected TableColumn<insertData, String> roomType;
    @FXML
    protected TableColumn<insertData, String> roomNo;
    @FXML
    protected TableColumn<insertData, String> status;
    @FXML
    protected TableColumn<insertData, String> info;
    @FXML
    protected TableColumn<insertData, Button> colBtn;
    protected String hotelName;


    @Override
    //reload the data from the json file (use the hotel name to know which file to get the data from)
    public void initialize(URL url, ResourceBundle resourceBundle) {
        UserHolder holder = UserHolder.getInstance();
        User u = holder.getUser();
        hotelName = u.getName();
        File f = new File("hotels/" + hotelName + "RoomBooking.json");
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        } else {
            readWriteFiles rwf = new readWriteFiles();
            JSONArray roomArr = rwf.dbRead(f);
            ObservableList<insertData> insert = FXCollections.observableArrayList();
            table.setItems(insert);
            for (int i = 0; i < roomArr.length(); i++) {
                try {
                    String roomType = roomArr.getJSONObject(i).get("RoomType").toString();
                    int roomNo = (int) roomArr.getJSONObject(i).get("RoomNO");
                    String stat = roomArr.getJSONObject(i).get("Status").toString();
                    String enterDate = roomArr.getJSONObject(i).get("EnterDate").toString();
                    String endDate = roomArr.getJSONObject(i).get("EndDate").toString();
                    Button btn = new Button("Manage");
                    btn.setDisable(true);
                    insertDataOb(insert, roomType, roomNo, stat, enterDate + " / " + endDate, btn);
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        try {
            fixTheTable();
        } catch (NullPointerException e) {
        }
    }

    //Fix the columns and insert the data into ObservableList and add buttons
    public void fixTheTable() {
        roomType.setCellValueFactory(new PropertyValueFactory<>("roomType"));
        roomNo.setCellValueFactory(new PropertyValueFactory<>("roomNo"));
        info.setCellValueFactory(new PropertyValueFactory<>("info"));
        colBtn.setCellValueFactory(new PropertyValueFactory<>("btn"));
        status.setCellValueFactory(new PropertyValueFactory<>("status"));
        status.setCellFactory(new Callback<TableColumn<insertData, String>, TableCell<insertData, String>>() {
            @Override
            public TableCell<insertData, String> call(TableColumn<insertData, String> param) {
                return new TableCell<insertData, String>() {

                    @Override
                    public void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        if (!isEmpty()) {
                            this.setTextFill(Color.GREEN);
                            if (item.contains("Un"))
                                this.setTextFill(Color.RED);
                            setText(item);
                        }
                    }
                };
            }
        });
    }

    //insert data into ObservableList using the class insertData
    public void insertDataOb(ObservableList<insertData> insert, String roomType, int roomNo, String status, String date, Button button) {
        insert.add(new insertData(roomType, roomNo, status, date, button));
    }

    //open booking form to enter the person info
    public void manage(ActionEvent e) {
        table.getSelectionModel().getSelectedItem().getBtn().setDisable(true);
        Parent root = null;
        try {
            root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/bookingRoom.fxml")));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.setResizable(false);
        stage.setTitle("Booking Room");
        stage.setScene(scene);
        stage.show();
    }

    //double click to show the button and select it OR one click to set the button disable
    public void selectRow(MouseEvent mouseEvent) {
        if (mouseEvent.getClickCount() == 2) {
            table.getSelectionModel().getSelectedItem().getBtn().setDisable(false);
            User u = new User();
            UserHolder holder = UserHolder.getInstance();
            holder.setUser(u);
            u.setRoomNum(table.getSelectionModel().getSelectedItem().getRoomNo());
            u.setRoomType(table.getSelectionModel().getSelectedItem().getRoomType());
            u.setName(hotelName);
            table.getSelectionModel().getSelectedItem().getBtn().setOnAction(this::manage);
        }
        if (mouseEvent.getClickCount() == 1) {
            table.getSelectionModel().getSelectedItem().getBtn().setDisable(true);
        }
    }
}
