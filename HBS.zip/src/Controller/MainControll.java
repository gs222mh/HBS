package Controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

import static Main.main.primaryStage;

public class MainControll implements Initializable {
    @FXML
    private Menu adminBar;
    @FXML
    private Menu employees;
    @FXML
    private MenuItem logoutItem;
    @FXML
    private MenuItem loginItem;
    public static boolean activeAdmin = true;
    public static boolean activeEmployees = true;
    public static Stage bookingStage;

    //open about window
    public void about() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/about.fxml")));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.initOwner(primaryStage);
        stage.initModality(Modality.WINDOW_MODAL);
        stage.setResizable(false);
        stage.setTitle("About HBS");
        stage.setScene(scene);
        stage.show();
    }

    //open login window
    public void login() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/login.fxml")));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.initOwner(primaryStage);
        stage.initModality(Modality.WINDOW_MODAL);
        stage.setResizable(false);
        stage.setTitle("Login HBS");
        stage.setScene(scene);
        stage.show();
    }

    //open create window
    public void create() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/new.fxml")));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.initOwner(primaryStage);
        stage.initModality(Modality.WINDOW_MODAL);
        stage.setResizable(false);
        stage.setTitle("Create HBS");
        stage.setScene(scene);
        stage.show();
    }

    //open editBasicInfo window
    public void editBasicInfo() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/editBasicInfo.fxml")));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.initOwner(primaryStage);
        stage.initModality(Modality.WINDOW_MODAL);
        stage.setResizable(false);
        stage.setTitle("Edit Basic Information");
        stage.setScene(scene);
        stage.show();
    }

    //exit from the program
    public void exit() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Close");
        alert.setHeaderText("Do you want to close this Window?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            System.exit(0);
        } else if (result.get() == ButtonType.CANCEL) {
            alert.close();
        }
    }

    //Logout from admin and employees MenuItem
    public void logout() {
        adminBar.setDisable(true);
        employees.setDisable(true);
        activeAdmin = true;
        activeEmployees = true;
        logoutItem.setDisable(true);
        loginItem.setDisable(false);
    }

    //If login is successful open admin or employees
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        primaryStage.setOnCloseRequest(evt -> {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirm Close");
            alert.setHeaderText("Do you want to close this Window?");
            alert.showAndWait().filter(r -> r != ButtonType.OK).ifPresent(r -> evt.consume());
        });
        if (!activeAdmin) {
            adminBar.setDisable(activeAdmin);
            logoutItem.setDisable(activeAdmin);
            loginItem.setDisable(!activeAdmin);
        }
        if (!activeEmployees) {
            employees.setDisable(activeEmployees);
            logoutItem.setDisable(activeEmployees);
            loginItem.setDisable(!activeEmployees);
        }
    }

    //open editEmployees window
    public void editEmployees() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/employees.fxml")));
        Stage stage = new Stage();
        Scene scene = new Scene(root);
        stage.initOwner(primaryStage);
        stage.initModality(Modality.WINDOW_MODAL);
        stage.setResizable(false);
        stage.setTitle("Employees");
        stage.setScene(scene);
        stage.show();
    }

    //open bookingManage window
    public void bookingManage() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/Fxml/bookingManage.fxml")));
        bookingStage = new Stage();
        Scene scene = new Scene(root);
        bookingStage.initOwner(primaryStage);
        bookingStage.initModality(Modality.WINDOW_MODAL);
        bookingStage.setResizable(false);
        bookingStage.setTitle("Booking Manage");
        bookingStage.setScene(scene);
        bookingStage.show();
    }
}
