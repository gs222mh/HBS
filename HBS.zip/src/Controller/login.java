package Controller;

import Main.main;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.json.JSONException;
import org.json.simple.*;
import org.json.simple.parser.*;

import java.io.*;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.util.Objects;
import java.util.ResourceBundle;

import static Main.main.primaryStage;


public class login extends MainControll implements Initializable {
    @FXML
    protected ChoiceBox<String> hotels;
    @FXML
    protected ChoiceBox<String> rules;
    @FXML
    protected Button cancelBtn;
    @FXML
    protected Button loginBut;
    @FXML
    protected TextField username;
    @FXML
    protected PasswordField pass;
    @FXML
    protected Text feedBack;

    //Show all hotels to select one to login
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        File folder = new File("hotels/");
        if (folder.exists()) {
            File[] listOfFiles = folder.listFiles();
            for (int i = 0; i < Objects.requireNonNull(listOfFiles).length; i++) {
                if (listOfFiles[i].getName().contains("Basic")) {
                    String hotelName = listOfFiles[i].getName();
                    hotelName = hotelName.replace("BasicInfo", "");
                    hotelName = hotelName.replace(".json", "");
                    hotels.getItems().add(hotelName);
                }
            }
        }
        rules.getItems().add("Admin");
        rules.getItems().add("Employer");
        hotels.setValue("Choose a hotel");
        rules.setValue("Choose a rules");
    }

    //close the new window
    public void close() {
        Stage stage = (Stage) cancelBtn.getScene().getWindow();
        stage.close();
    }

    //Get back the color
    public void boxBorder() {
        username.setStyle("-fx-text-box-border: #EBE9ED;");
        pass.setStyle("-fx-text-box-border: #EBE9ED;");
    }

    //login button
    public void login() {
        boxBorder();
        if (!hotels.getValue().equals("Choose a hotel") && rules.getValue().equals("Admin")) {
            JSONParser parser = new JSONParser();
            try {
                Object obj = parser.parse(new FileReader("hotels/BasicInfo" + hotels.getValue() + ".json"));
                JSONObject jsonObject = (JSONObject) obj;
                JSONObject hoteInfo = (JSONObject) jsonObject.get("hotelInfo");
                JSONObject adminInfo = (JSONObject) jsonObject.get("admin");
                String hotelName = (String) hoteInfo.get("hotelName");
                String user = (String) adminInfo.get("adminUsername");
                String password = (String) adminInfo.get("adminPassword");
                hashing hashing = new hashing();
                if (user.equals(username.getText()) && password.equals(hashing.hasing(pass.getText()))) {
                    Stage stage = (Stage) cancelBtn.getScene().getWindow();
                    stage.close();
                    activeAdmin = false;
                    Platform.runLater(() -> {
                        try {
                            new main().start(primaryStage);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
                    User u = new User();
                    UserHolder holder = UserHolder.getInstance();
                    holder.setUser(u);
                    u.setName(hotelName);
                } else {
                    feedBack.setText("The username or password is not correct");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (!hotels.getValue().equals("Choose a hotel") && rules.getValue().equals("Employer")) {
            String usernamee;
            String password;
            File f = new File("hotels/" + hotels.getValue() + "Employees.json");
            readWriteFiles rwf = new readWriteFiles();
            org.json.JSONArray employeesArr = rwf.dbRead(f);
            for (int i = 0; i < employeesArr.length(); i++) {
                try {
                    usernamee = employeesArr.getJSONObject(i).get("Username").toString();
                    password = employeesArr.getJSONObject(i).get("Password").toString();
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
                hashing hashing = new hashing();
                try {
                    if (usernamee.equals(username.getText()) && password.equals(hashing.hasing(pass.getText()))) {
                        Stage stage = (Stage) cancelBtn.getScene().getWindow();
                        stage.close();
                        activeEmployees = false;
                        Platform.runLater(() -> {
                            try {
                                new main().start(primaryStage);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        });
                    } else {
                        feedBack.setText("The username or password is not correct");
                    }
                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        if (username.getText().equals("")) username.setStyle("-fx-text-box-border: #B22222;");
        if (pass.getText().equals("")) pass.setStyle("-fx-text-box-border: #B22222;");
    }
}
