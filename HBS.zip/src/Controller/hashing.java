package Controller;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class hashing {
    public hashing() {
    }
    //Hashing all password
    public String hasing(String pass) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(pass.getBytes(StandardCharsets.UTF_8));
        String hasingPass = Base64.getEncoder().encodeToString(hash);
        return hasingPass;
    }
}
