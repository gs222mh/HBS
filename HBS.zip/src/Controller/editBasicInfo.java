package Controller;

import Main.main;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.ResourceBundle;

public class editBasicInfo implements Initializable {
    @FXML
    protected Button cancelBtn;
    @FXML
    protected Button nextBtn;
    @FXML
    protected Button addImage;
    @FXML
    protected TextField hotelNameField;
    @FXML
    protected TextField country;
    @FXML
    protected TextField city;
    @FXML
    protected TextField tel;
    @FXML
    protected TextField email;
    @FXML
    protected ChoiceBox<Integer> single;
    @FXML
    protected ChoiceBox<Integer> triple;
    @FXML
    protected ChoiceBox<Integer> double1;
    @FXML
    protected ChoiceBox<Integer> twin;
    @FXML
    protected ChoiceBox<Integer> king;
    @FXML
    protected ChoiceBox<Integer> quad;
    @FXML
    protected ChoiceBox<String> sip;
    @FXML
    protected ChoiceBox<String> dp;
    @FXML
    protected ChoiceBox<String> trp;
    @FXML
    protected ChoiceBox<String> kp;
    @FXML
    protected ChoiceBox<String> qp;
    @FXML
    protected ChoiceBox<String> quep;
    @FXML
    protected ChoiceBox<String> sp;
    @FXML
    protected ChoiceBox<String> tp;
    @FXML
    protected TextField username;
    @FXML
    protected PasswordField pass;
    @FXML
    protected ChoiceBox<Integer> queen;
    @FXML
    protected ChoiceBox<Integer> studio;
    private String hotelName;
    private final ObservableList<Integer> numOfRoom = FXCollections.observableArrayList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
    private final ObservableList<String> prisNum = FXCollections.observableArrayList("5$", "10$", "15$", "20$", "25$", "30$", "35$", "40$", "45$", "50$", "55$", "60$", "65$", "70$", "75$", "80$", "85$", "90$", "95$", "100$");

    @FXML
    protected ImageView hotelImage;
    private File select = null;

    //close the new window
    public void close() {
        Stage stage = (Stage) cancelBtn.getScene().getWindow();
        stage.close();
    }

    //Go to the next step if all basic information are good
    public void next() throws IOException, JSONException, NoSuchAlgorithmException {
        boxBorder();
        if (!country.getText().equals("") && !city.getText().equals("") && !tel.getText().equals("") && !email.getText().equals("") && !select.getAbsolutePath().equals("") && !username.getText().equals("") && !pass.getText().equals("")) {
            if (createFile()) {
                close();
                savingInfo("hotels/BasicInfo" + hotelNameField.getText() + ".json");
            }
        }
        if (pass.getText().equals("")) pass.setStyle("-fx-text-box-border: #B22222;");
        if (country.getText().equals("")) country.setStyle("-fx-text-box-border: #B22222;");
        if (city.getText().equals("")) city.setStyle("-fx-text-box-border: #B22222;");
        if (tel.getText().equals("")) tel.setStyle("-fx-text-box-border: #B22222;");
        if (email.getText().equals("")) email.setStyle("-fx-text-box-border: #B22222;");
        if (select == null) addImage.setStyle("-fx-border-color: #B22222;");
    }

    //Get back to the default box-border
    public void boxBorder() {
        hotelNameField.setStyle("-fx-text-box-border: #EBE9ED;");
        country.setStyle("-fx-text-box-border: #EBE9ED;");
        city.setStyle("-fx-text-box-border: #EBE9ED;");
        tel.setStyle("-fx-text-box-border: #EBE9ED;");
        email.setStyle("-fx-text-box-border: #EBE9ED;");
        addImage.setStyle("-fx-text-box-border: #EBE9ED;");
        pass.setStyle("-fx-text-box-border: #EBE9ED;");
    }

    //Create a json file to save all data
    public boolean createFile() {
        boolean fileExist = false;
        File theDir = new File("hotels");
        if (!theDir.exists()) {
            theDir.mkdirs();
        }
        File myObj = new File("hotels/BasicInfo" + hotelNameField.getText() + ".json");
        if (myObj.exists()) {
            fileExist = true;
        }
        return fileExist;
    }

    //Saving all data on the json file
    public void savingInfo(String filename) throws JSONException, IOException, NoSuchAlgorithmException {
        JSONObject hotelInfo = new JSONObject();
        hotelInfo.put("hotelName", hotelNameField.getText());
        hotelInfo.put("country", country.getText());
        hotelInfo.put("city", city.getText());
        hotelInfo.put("tel", tel.getText());
        hotelInfo.put("email", email.getText());
        hotelInfo.put("imageURL", select.getAbsolutePath());
        hotelInfo.put("single", single.getValue());
        hotelInfo.put("double", double1.getValue());
        hotelInfo.put("triple", triple.getValue());
        hotelInfo.put("king", king.getValue());
        hotelInfo.put("queen", queen.getValue());
        hotelInfo.put("quad", quad.getValue());
        hotelInfo.put("twin", twin.getValue());
        hotelInfo.put("studio", studio.getValue());
        JSONObject adminInfo = new JSONObject();
        hashing hashing = new hashing();
        adminInfo.put("adminUsername", username.getText());
        adminInfo.put("adminPassword", hashing.hasing(pass.getText()));
        JSONObject prisInfo = new JSONObject();
        prisInfo.put("sip", sip.getValue());
        prisInfo.put("dp", dp.getValue());
        prisInfo.put("trp", trp.getValue());
        prisInfo.put("kp", kp.getValue());
        prisInfo.put("quep", quep.getValue());
        prisInfo.put("qp", qp.getValue());
        prisInfo.put("tp", tp.getValue());
        prisInfo.put("sp", sp.getValue());
        JSONObject mainObj = new JSONObject();
        mainObj.put("admin", adminInfo);
        mainObj.put("hotelInfo", hotelInfo);
        mainObj.put("prisInfo", prisInfo);
        Files.write(Paths.get(filename), Collections.singleton(mainObj.toString()));
    }

    //Select the image and get the URL
    @FXML
    private void selectImage() throws FileNotFoundException {
        FileChooser file = new FileChooser();
        file.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("All Images", "*.*"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("JPGE", "*.jpge"),
                new FileChooser.ExtensionFilter("PNG", "*.png"));
        select = file.showOpenDialog(main.primaryStage);
        InputStream stream = new FileInputStream(select.getAbsolutePath());
        Image image = new Image(stream);
        hotelImage.setImage(image);
    }

    //Get all information about the selected hotel and show it to the admin to edit it
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        UserHolder holder = UserHolder.getInstance();
        User u = holder.getUser();
        hotelName = u.getName();
        JSONParser parser = new JSONParser();
        try {
            Object obj = parser.parse(new FileReader("hotels/BasicInfo" + hotelName + ".json"));
            org.json.simple.JSONObject jsonObject = (org.json.simple.JSONObject) obj;
            org.json.simple.JSONObject hotelInfo = (org.json.simple.JSONObject) jsonObject.get("hotelInfo");
            String hotelName = (String) hotelInfo.get("hotelName");
            String countryInfo = (String) hotelInfo.get("country");
            String cityInfo = (String) hotelInfo.get("city");
            String telInfo = (String) hotelInfo.get("tel");
            String emailInfo = (String) hotelInfo.get("email");
            String imageURLInfo = (String) hotelInfo.get("imageURL");
            String studioInfo = hotelInfo.get("studio").toString();
            String kingInfo = hotelInfo.get("king").toString();
            String queenInfo = hotelInfo.get("queen").toString();
            String doubleInfo = hotelInfo.get("double").toString();
            String singleInfo = hotelInfo.get("single").toString();
            String quadInfo = hotelInfo.get("quad").toString();
            String tripleInfo = hotelInfo.get("triple").toString();
            String twinInfo = hotelInfo.get("twin").toString();
            org.json.simple.JSONObject adminInfo = (org.json.simple.JSONObject) jsonObject.get("admin");
            String adminUsername = (String) adminInfo.get("adminUsername");
            org.json.simple.JSONObject prisInfo = (org.json.simple.JSONObject) jsonObject.get("prisInfo");
            String studioPris = prisInfo.get("studioPris").toString();
            String kingPris = prisInfo.get("kingPris").toString();
            String queenPris = prisInfo.get("queenPris").toString();
            String doublePris = prisInfo.get("doublePris").toString();
            String singlePris = prisInfo.get("singlePris").toString();
            String quadPris = prisInfo.get("quadPris").toString();
            String triplePris = prisInfo.get("triplePris").toString();
            String twinPris = prisInfo.get("twinPris").toString();

            studio.setValue(Integer.valueOf(studioInfo));
            single.setValue(Integer.valueOf(singleInfo));
            double1.setValue(Integer.valueOf(doubleInfo));
            triple.setValue(Integer.valueOf(tripleInfo));
            quad.setValue(Integer.valueOf(quadInfo));
            queen.setValue(Integer.valueOf(queenInfo));
            king.setValue(Integer.valueOf(kingInfo));
            twin.setValue(Integer.valueOf(twinInfo));

            sip.setValue(singlePris);
            dp.setValue(doublePris);
            trp.setValue(triplePris);
            kp.setValue(kingPris);
            quep.setValue(queenPris);
            qp.setValue(quadPris);
            tp.setValue(twinPris);
            sp.setValue(studioPris);

            InputStream stream = new FileInputStream(imageURLInfo);
            Image image = new Image(stream);
            hotelImage.setImage(image);
            hotelNameField.setText(hotelName);
            hotelNameField.setDisable(true);
            country.setText(countryInfo);
            tel.setText(telInfo);
            email.setText(emailInfo);
            city.setText(cityInfo);
            username.setText(adminUsername);
            select = new File(imageURLInfo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        single.setItems(numOfRoom);
        double1.setItems(numOfRoom);
        triple.setItems(numOfRoom);
        quad.setItems(numOfRoom);
        queen.setItems(numOfRoom);
        king.setItems(numOfRoom);
        studio.setItems(numOfRoom);
        twin.setItems(numOfRoom);

        sip.setItems(prisNum);
        dp.setItems(prisNum);
        trp.setItems(prisNum);
        qp.setItems(prisNum);
        quep.setItems(prisNum);
        kp.setItems(prisNum);
        sp.setItems(prisNum);
        tp.setItems(prisNum);
    }
}
